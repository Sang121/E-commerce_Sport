@extends('customer.layout.layout')

@section('content')
    <div class="alert alert-danger" role="alert">
        Đã có lỗi xảy ra trong quá trình thanh toán. Vui lòng thử lại sau.
    </div>
@endsection
