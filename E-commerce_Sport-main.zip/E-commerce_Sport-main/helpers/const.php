<?php
const DOT = '.';

const OBJECT_CATEGORIES = 'categories';
const OBJECT_PRODUCTS = 'products';
